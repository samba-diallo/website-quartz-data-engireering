#!/usr/bin/env bash
# Cloud-init / user-data script for Amazon Linux 2
set -e

# Update and install Node.js
yum update -y
curl -sL https://rpm.nodesource.com/setup_21.x | bash -
yum install -y nodejs

# Download the sample app (adjust URL if you host it elsewhere)
if [ ! -f /home/ec2-user/app.js ]; then
  curl -s -o /home/ec2-user/app.js https://raw.githubusercontent.com/your-repo/sample-app/main/app.js || true
  chown ec2-user:ec2-user /home/ec2-user/app.js || true
fi

# Start the Node.js app in background
nohup node /home/ec2-user/app.js > /home/ec2-user/app.log 2>&1 &
#!/usr/bin/env bash
# Install updates and Node.js, then run the app
yum update -y
curl -sL https://rpm.nodesource.com/setup_21.x | bash -
yum install -y nodejs

# Download the sample app from GitHub
curl -o /home/ec2-user/app.js https://raw.githubusercontent.com/samba-diallo/monAppli/main/ch1/sample-app/app.js

# Start the Node.js app
nohup node /home/ec2-user/app.js &
