#!/usr/bin/env bash
set -euo pipefail

export AWS_DEFAULT_REGION="us-east-2"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
user_data=$(cat "$SCRIPT_DIR/user-data.sh")

# Nom unique pour le security group
TIMESTAMP=$(date +%s)
SG_NAME="sample-app-${TIMESTAMP}"

# Créer le security group
security_group_id=$(aws ec2 create-security-group \
  --group-name "$SG_NAME" \
  --description "Allow HTTP traffic into the sample app" \
  --output text \
  --query GroupId)

# Ouvrir le port 8080
aws ec2 authorize-security-group-ingress \
  --group-id "$security_group_id" \
  --protocol tcp \
  --port 8080 \
  --cidr "0.0.0.0/0" > /dev/null || true

# Lancer l'instance EC2
instance_id=$(aws ec2 run-instances \
  --image-id "ami-0900fe555666598a2" \
  --instance-type "t3.micro" \
  --security-group-ids "$security_group_id" \
  --user-data "$user_data" \
  --tag-specifications "ResourceType=instance,Tags=[{Key=Name,Value=${SG_NAME}}]" \
  --output text \
  --query 'Instances[0].InstanceId')

# Attendre que l'instance soit en état running
aws ec2 wait instance-running --instance-ids "$instance_id"

# Récupérer l'adresse IP publique
public_ip=$(aws ec2 describe-instances \
  --instance-ids "$instance_id" \
  --output text \
  --query 'Reservations[0].Instances[0].PublicIpAddress')

# Résumé
echo "Instance ID: $instance_id"
echo "Security Group ID: $security_group_id"
echo "Security Group Name: $SG_NAME"
echo "Public IP: $public_ip"

# Commandes de nettoyage
echo ""
echo "Commands to cleanup:"
echo "  aws ec2 terminate-instances --instance-ids $instance_id"
echo "  aws ec2 wait instance-terminated --instance-ids $instance_id"
echo "  aws ec2 delete-security-group --group-id $security_group_id"
