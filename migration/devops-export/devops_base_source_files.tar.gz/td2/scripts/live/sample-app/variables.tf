variable "ami_id" {
  description = "The ID of the AMI to run."
  type        = string
}

variable "instance_type" {
  description = "EC2 instance type"
  type        = string
  default     = "t3.micro"
}

variable "port" {
  description = "Port for HTTP traffic"
  type        = number
  default     = 8080
}
