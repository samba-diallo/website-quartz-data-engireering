output "sample_app_1" {
  description = "Details for sample-app-1"
  value = {
    instance_id     = module.sample_app_1.instance_id
    public_ip       = module.sample_app_1.public_ip
    security_group  = module.sample_app_1.security_group_id
  }
}

output "sample_app_2" {
  description = "Details for sample-app-2"
  value = {
    instance_id     = module.sample_app_2.instance_id
    public_ip       = module.sample_app_2.public_ip
    security_group  = module.sample_app_2.security_group_id
  }
}

output "all_public_ips" {
  description = "All public IPs"
  value = [
    module.sample_app_1.public_ip,
    module.sample_app_2.public_ip
  ]
}
