provider "aws" {
  region  = "us-east-2"
  profile = "labs-devops_diallo"
}

module "sample_app_1" {
  source        = "../../modules/ec2-instance"
  ami_id        = var.ami_id
  name          = "sample-app-tofu-1"
  instance_type = var.instance_type
  port          = var.port
}

module "sample_app_2" {
  source        = "../../modules/ec2-instance"
  ami_id        = var.ami_id
  name          = "sample-app-tofu-2"
  instance_type = var.instance_type
  port          = var.port
}
