# Variables for Section 7 - GitHub Modules

variable "ami_id" {
  description = "AMI ID to use for instances"
  type        = string
  default     = "ami-07eb809c44dd0fcab" # Replace with your Packer-built AMI
}

variable "instance_type" {
  description = "EC2 instance type"
  type        = string
  default     = "t3.micro"
}

variable "port" {
  description = "Port for the application"
  type        = number
  default     = 8080
}
