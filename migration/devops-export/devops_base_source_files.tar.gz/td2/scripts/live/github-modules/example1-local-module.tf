# Section 7 - Example 1: Using Local Module (Reference)
# This demonstrates our local module before transitioning to GitHub modules
# NOTE: Provider configuration is in main.tf (not duplicated here)

# Using our local module from ../../modules/ec2-instance
module "example1_local_sample_app" {
  source        = "../../modules/ec2-instance"
  ami_id        = var.ami_id
  name          = "example1-local-module-app"
  instance_type = var.instance_type
  port          = var.port
}
