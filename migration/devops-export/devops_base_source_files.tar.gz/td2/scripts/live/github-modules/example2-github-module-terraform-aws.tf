# Section 7 - Example 2: Using AWS VPC Module from GitHub
# This demonstrates using a real, production-ready module from GitHub
# Module: https://github.com/terraform-aws-modules/terraform-aws-vpc
# NOTE: Provider configuration is in main.tf (not duplicated here)

# Example: Using terraform-aws-modules/vpc/aws module (public, well-maintained)
# This is a REFERENCE - don't uncomment unless you have AWS credits to burn
# Uncomment to test with real public module:
/*
module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "5.0.0"

  name = "main-vpc"
  cidr = "10.0.0.0/16"

  azs             = ["us-east-2a", "us-east-2b"]
  private_subnets = ["10.0.1.0/24", "10.0.2.0/24"]
  public_subnets  = ["10.0.101.0/24", "10.0.102.0/24"]

  enable_nat_gateway = true
  single_nat_gateway = true

  tags = {
    Environment = "lab"
  }
}

output "vpc_id" {
  value = module.vpc.vpc_id
}

output "public_subnets" {
  value = module.vpc.public_subnets
}
*/

# This demonstrates the syntax and concept without deploying resources
