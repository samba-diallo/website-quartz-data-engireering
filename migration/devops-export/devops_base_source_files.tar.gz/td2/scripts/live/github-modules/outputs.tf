# Outputs for Section 7 - GitHub Modules

output "local_module_public_ip" {
  description = "Public IP of instance from local module"
  value       = module.local_module_instance.public_ip
}

output "local_module_instance_id" {
  description = "Instance ID from local module"
  value       = module.local_module_instance.instance_id
}

output "local_module_public_dns" {
  description = "Public DNS of instance from local module"
  value       = module.local_module_instance.public_dns
}

output "local_module_security_group" {
  description = "Security Group ID from local module"
  value       = module.local_module_instance.security_group_id
}
