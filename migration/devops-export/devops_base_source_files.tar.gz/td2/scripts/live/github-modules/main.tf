# Section 7: Using OpenTofu Modules from GitHub
# Main configuration for practical demonstration

provider "aws" {
  region  = "us-east-2"
  profile = "labs-devops_diallo"
}

# STEP 1: Local module (already working)
module "local_module_instance" {
  source        = "../../modules/ec2-instance"
  ami_id        = var.ami_id
  name          = "local-module-test"
  instance_type = var.instance_type
  port          = var.port
}

# STEP 2: GitHub module (example syntax)
# 
# To use this in production:
# 1. Push your local module to GitHub: github.com/YOUR_USERNAME/iac-modules.git
# 2. Create a release tag (e.g., v1.0.0)
# 3. Uncomment the module below
# 4. Replace YOUR_USERNAME with your GitHub username
# 5. Run: tofu init && tofu apply
#
# module "github_module_instance" {
#   source = "github.com/YOUR_USERNAME/iac-modules.git//ec2-instance?ref=v1.0.0"
#   
#   ami_id        = var.ami_id
#   name          = "github-module-test"
#   instance_type = var.instance_type
#   port          = var.port
# }
