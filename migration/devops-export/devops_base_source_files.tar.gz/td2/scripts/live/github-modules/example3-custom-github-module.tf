# Section 7 - Example 3: Using Custom Module from GitHub
# This demonstrates how to use a module from YOUR OWN GitHub repository
# NOTE: Provider configuration is in main.tf (not duplicated here)

# Pattern: github.com/username/repo-name.git//path/to/module
# 
# Example syntax (UNCOMMENT AND MODIFY with your actual GitHub details):
/*
module "github_sample_app" {
  source = "github.com/your-github-username/iac-modules.git//ec2-instance"
  
  # If you want to use a specific version/tag:
  # source = "github.com/your-github-username/iac-modules.git//ec2-instance?ref=v1.0.0"
  
  ami_id        = "ami-07eb809c44dd0fcab"  # Replace with your AMI ID
  name          = "github-module-app"
  instance_type = "t3.micro"
  port          = 8080
}

output "github_module_public_ip" {
  description = "Public IP from GitHub module"
  value       = module.github_sample_app.public_ip
}

output "github_module_instance_id" {
  description = "Instance ID from GitHub module"
  value       = module.github_sample_app.instance_id
}
output "github_module_security_group" {
  description = "Security Group ID from GitHub module"
  value       = module.github_sample_app.security_group_id
}
*/

# STEPS TO USE YOUR OWN GITHUB MODULE:
#
# 1. Create a GitHub repository (e.g., "iac-modules")
# 2. Push your local module to: username/iac-modules/ec2-instance
# 3. Create a GitHub tag/release (e.g., v1.0.0)
# 4. Uncomment the module block above
# 5. Replace "your-github-username" with your actual GitHub username
# 6. Run: tofu init && tofu apply
#
# VERSIONING OPTIONS:
# - Without ?ref: Uses default branch (main/master)
# - With ?ref=branch-name: Uses specific branch
# - With ?ref=v1.0.0: Uses specific Git tag/release (RECOMMENDED)
# - With ?ref=commit-sha: Uses specific commit hash
