# Section 7 - Example 4: Using Module with Version Constraints
# This demonstrates best practices for module versioning
# NOTE: Provider configuration is in main.tf (not duplicated here)

# PATTERN: Using version constraints with GitHub modules
# This ensures reproducibility and prevents unexpected changes
#
# Uncomment to use with your GitHub module:
/*
module "app_v1" {
  source = "github.com/your-github-username/iac-modules.git//ec2-instance?ref=v1.0.0"
  
  ami_id        = var.ami_id
  name          = "app-v1-0-0"
  instance_type = "t3.micro"
  port          = 8080
}

module "app_v1_latest" {
  source = "github.com/your-github-username/iac-modules.git//ec2-instance?ref=v1.2.0"
  
  ami_id        = var.ami_id
  name          = "app-v1-2-0"
  instance_type = "t3.micro"
  port          = 8080
}

module "app_latest" {
  source = "github.com/your-github-username/iac-modules.git//ec2-instance?ref=main"
  
  ami_id        = var.ami_id
  name          = "app-main-branch"
  instance_type = "t3.micro"
  port          = 8080
}

output "deployed_versions" {
  value = {
    v1_0_0 = module.app_v1.public_ip
    v1_2_0 = module.app_v1_latest.public_ip
    main   = module.app_latest.public_ip
  }
}
*/

# VERSIONING BEST PRACTICES:
#
# 1. SEMANTIC VERSIONING
#    Use: ?ref=v1.2.3
#    - v1.2.3: Major.Minor.Patch
#    - MAJOR: Breaking changes
#    - MINOR: New features, backwards compatible
#    - PATCH: Bug fixes
#
# 2. BRANCH-BASED
#    Use: ?ref=main or ?ref=develop
#    - Good for development
#    - Risk: Code may change
#    - Use for active development only
#
# 3. COMMIT-BASED
#    Use: ?ref=abc123def456
#    - Most precise
#    - Good for debugging specific commits
#    - Less maintainable long-term
#
# 4. RECOMMENDED APPROACH
#    - Use semantic versioning in production (?ref=v1.0.0)
#    - Use branches in development (?ref=develop)
#    - Update versions in controlled manner
#    - Document version changes in CHANGELOG
