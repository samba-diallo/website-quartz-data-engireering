provider "aws" {
  region  = "us-east-2"
  profile = "labs-devops_diallo"
}

variable "ami_id" {
  description = "The ID of the AMI to run."
  type        = string
}

variable "instances" {
  description = "Map of instances to create"
  type = map(object({
    name          = string
    instance_type = string
    port          = number
  }))
  default = {
    "prod-1" = {
      name          = "prod-app-1"
      instance_type = "t3.micro"
      port          = 8080
    }
    "prod-2" = {
      name          = "prod-app-2"
      instance_type = "t3.micro"
      port          = 8080
    }
    "prod-3" = {
      name          = "prod-app-3"
      instance_type = "t3.micro"
      port          = 8080
    }
  }
}

module "sample_apps" {
  for_each      = var.instances
  source        = "../../modules/ec2-instance"
  ami_id        = var.ami_id
  name          = each.value.name
  instance_type = each.value.instance_type
  port          = each.value.port
}

output "instances" {
  description = "Details of all deployed instances"
  value = {
    for key, instance in module.sample_apps :
    key => {
      instance_id     = instance.instance_id
      public_ip       = instance.public_ip
      security_group  = instance.security_group_id
    }
  }
}

output "public_ips" {
  description = "All public IPs"
  value = {
    for key, instance in module.sample_apps :
    key => instance.public_ip
  }
}
