#!/usr/bin/env bash
# Cleanup helper for lab resources — interactive and idempotent where possible.
# Usage:
#   INSTANCE_ID=... SG_ID=... AMI_ID=... KEY_NAME=... ./cleanup.sh
# or export variables beforehand.
set -euo pipefail

INSTANCE_ID=${INSTANCE_ID:-}
SG_ID=${SG_ID:-}
AMI_ID=${AMI_ID:-}
KEY_NAME=${KEY_NAME:-}

function info { echo "[INFO] $*"; }
function warn { echo "[WARN] $*"; }

if [ -z "$INSTANCE_ID" ] && [ -z "$SG_ID" ] && [ -z "$AMI_ID" ] && [ -z "$KEY_NAME" ]; then
  echo "Rien à faire : exporte au moins une variable parmi INSTANCE_ID, SG_ID, AMI_ID, KEY_NAME"
  exit 0
fi

if [ -n "$INSTANCE_ID" ]; then
  info "Terminating instance $INSTANCE_ID"
  aws ec2 terminate-instances --instance-ids "$INSTANCE_ID" || warn "terminate failed"
  aws ec2 wait instance-terminated --instance-ids "$INSTANCE_ID" || warn "wait terminated failed"
fi

if [ -n "$SG_ID" ]; then
  info "Deleting security group $SG_ID"
  aws ec2 delete-security-group --group-id "$SG_ID" || warn "delete sg failed (in-use or already removed)"
fi

if [ -n "$KEY_NAME" ]; then
  info "Deleting key pair $KEY_NAME"
  aws ec2 delete-key-pair --key-name "$KEY_NAME" || warn "delete key failed"
  # remove any local file matching key name
  rm -f "${KEY_NAME}.pem" || true
fi

if [ -n "$AMI_ID" ]; then
  info "Deregistering AMI $AMI_ID"
  aws ec2 deregister-image --image-id "$AMI_ID" || warn "deregister failed"
  # try to find snapshots associated and warn user to delete them manually
  snaps=$(aws ec2 describe-snapshots --filters Name=description,Values="*${AMI_ID}*" --query 'Snapshots[*].SnapshotId' --output text || true)
  if [ -n "$snaps" ]; then
    warn "Snapshots associated with AMI: $snaps. Delete them manually if you want to free storage costs: aws ec2 delete-snapshot --snapshot-id <id>"
  fi
fi

info "Nettoyage terminé (vérifie la console AWS pour confirmer)."
