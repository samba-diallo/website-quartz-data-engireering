#!/bin/bash
echo 'const http = require("http"); const s = http.createServer((q, r) => { r.end("Hello, World!"); }); s.listen(8080);' > /tmp/app.js
/usr/local/bin/node /tmp/app.js &
