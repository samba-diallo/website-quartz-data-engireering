variable "ami_id" {
  description = "The ID of the AMI to run."
  type        = string
}

variable "name" {
  description = "The base name for the instance and all other resources"
  type        = string
  default     = "sample-app-tofu"
}

variable "instance_type" {
  description = "EC2 instance type"
  type        = string
  default     = "t2.micro"
}
