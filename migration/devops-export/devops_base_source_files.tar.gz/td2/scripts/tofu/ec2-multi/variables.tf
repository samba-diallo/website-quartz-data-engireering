variable "ami_id" {
  description = "The ID of the AMI to run."
  type        = string
}

variable "instance_names" {
  description = "Names for each instance"
  type        = list(string)
  default     = ["sample-app-1", "sample-app-2", "sample-app-3"]
}
