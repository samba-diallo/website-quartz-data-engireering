output "instance_details" {
  description = "Details of all deployed instances"
  value = {
    for name, instance in aws_instance.sample_app_multi :
    name => {
      instance_id     = instance.id
      public_ip       = instance.public_ip
      private_ip      = instance.private_ip
      public_dns      = instance.public_dns
    }
  }
}

output "instance_ips" {
  description = "Public IPs of all instances"
  value = {
    for name, instance in aws_instance.sample_app_multi :
    name => instance.public_ip
  }
}

output "security_group_id" {
  description = "The ID of the security group"
  value       = aws_security_group.sample_app.id
}
