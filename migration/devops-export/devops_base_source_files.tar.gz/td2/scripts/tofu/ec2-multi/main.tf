provider "aws" {
  region  = "us-east-2"
  profile = "labs-devops_diallo"
}

resource "aws_security_group" "sample_app" {
  name        = "sample-app-tofu-multi"
  description = "Allow HTTP traffic into the sample apps"
}

resource "aws_security_group_rule" "allow_http_inbound" {
  type              = "ingress"
  protocol          = "tcp"
  from_port         = 8080
  to_port           = 8080
  security_group_id = aws_security_group.sample_app.id
  cidr_blocks       = ["0.0.0.0/0"]
}

resource "aws_instance" "sample_app_multi" {
  for_each                      = toset(var.instance_names)
  ami                           = var.ami_id
  instance_type                 = "t3.micro"
  vpc_security_group_ids        = [aws_security_group.sample_app.id]
  user_data                     = file("${path.module}/user-data.sh")
  user_data_replace_on_change   = true

  tags = {
    Name = each.value
  }
}
