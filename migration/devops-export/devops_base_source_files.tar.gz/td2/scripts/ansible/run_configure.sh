#!/usr/bin/env bash
set -euo pipefail
# Helper script to validate connectivity and run the Ansible configure playbook
# Usage: ./run_configure.sh [INSTANCE_IP]

ROOT_DIR=$(cd "$(dirname "$0")" && pwd)
cd "$ROOT_DIR"

KEY="./ansible-ch2.key"
IP="${1:-3.142.134.207}"
AWS_PROFILE="${AWS_PROFILE:-labs-devops_diallo}"

echo "[info] working dir: $ROOT_DIR"

if [[ ! -f "$KEY" ]]; then
  echo "[error] private key not found at $KEY"
  echo "Place the ansible-ch2.key file in $ROOT_DIR or update group_vars/ch2_instances.yml"
  exit 2
fi

echo "[info] securing private key permissions"
chmod 600 "$KEY"

echo "[info] checking AWS identity (profile=$AWS_PROFILE)"
if ! aws sts get-caller-identity --profile "$AWS_PROFILE" >/dev/null 2>&1; then
  echo "[error] aws sts get-caller-identity failed using profile $AWS_PROFILE"
  echo "Ensure your AWS CLI is configured and the profile exists."
  exit 3
fi

echo "[info] testing SSH connectivity to $IP"
if ssh -o BatchMode=yes -o StrictHostKeyChecking=no -o ConnectTimeout=10 -i "$KEY" ec2-user@"$IP" 'echo SSH_OK' >/dev/null 2>&1; then
  echo "[info] SSH connection OK"
else
  echo "[warn] SSH test failed (timeout or auth). Continuing to run Ansible to surface detailed errors."
fi

echo "[info] running ansible-playbook configure_sample_app_playbook.yml"
ANSIBLE_PYTHON_INTERPRETER="${ANSIBLE_PYTHON_INTERPRETER:-$(which python3)}" \
AWS_PROFILE="$AWS_PROFILE" \
ansible-playbook -i inventory.aws_ec2.yml -v configure_sample_app_playbook.yml || {
  echo "[error] ansible-playbook failed — see output above. Provide the error here and I will help debug."
  exit 4
}

echo "[info] waiting 3s for the app to start and then testing HTTP on port 8080"
sleep 3
if curl -sS "http://$IP:8080/" | sed -n '1,120p'; then
  echo "[info] HTTP check succeeded"
else
  echo "[warn] HTTP check failed — app may not be running or port blocked by SG"
fi

echo "[done] run completed"
