#!/usr/bin/env bash
set -euo pipefail

# Script to finalize deployment:
# 1. Extract SG ID from running instance
# 2. Add ingress rule for port 8080
# 3. Re-run Ansible configure playbook with corrected app.js
# 4. Verify HTTP connectivity

ROOT_DIR=$(cd "$(dirname "$0")" && pwd)
cd "$ROOT_DIR"

KEY="./ansible-ch2.key"
INSTANCE_ID="i-0d9e97dcfeef9c1d9"
INSTANCE_IP="3.142.134.207"
PROFILE="${AWS_PROFILE:-labs-devops_diallo}"
REGION="us-east-2"

echo "[step 1] Extracting Security Group ID from instance $INSTANCE_ID"
SG_ID=$(aws ec2 describe-instances \
  --instance-ids "$INSTANCE_ID" \
  --query 'Reservations[0].Instances[0].SecurityGroups[0].GroupId' \
  --output text \
  --profile "$PROFILE" \
  --region "$REGION")

echo "[info] Security Group ID: $SG_ID"

echo "[step 2] Adding ingress rule for port 8080 to $SG_ID"
if aws ec2 authorize-security-group-ingress \
  --group-id "$SG_ID" \
  --protocol tcp \
  --port 8080 \
  --cidr 0.0.0.0/0 \
  --profile "$PROFILE" \
  --region "$REGION" 2>/dev/null; then
  echo "[info] Ingress rule added successfully"
else
  echo "[info] Ingress rule already exists or could not be added (continuing...)"
fi

echo "[step 3] Securing private key permissions"
chmod 600 "$KEY"

echo "[step 4] Running Ansible configure playbook to deploy corrected app.js"
ANSIBLE_PYTHON_INTERPRETER="$(which python3)" \
AWS_PROFILE="$PROFILE" \
ansible-playbook -i inventory.aws_ec2.yml -v configure_sample_app_playbook.yml

echo "[step 5] Waiting 5 seconds for app to start/restart"
sleep 5

echo "[step 6] Testing HTTP connectivity to $INSTANCE_IP:8080"
if curl -sS "http://$INSTANCE_IP:8080/" 2>&1 | head -n 20; then
  echo "[success] HTTP test passed - app is reachable!"
else
  echo "[warn] HTTP test failed - trying SSH diagnostics..."
  
  echo "[diag] Checking if node process is running..."
  if ssh -o StrictHostKeyChecking=no -o BatchMode=yes -i "$KEY" ec2-user@"$INSTANCE_IP" \
    'ps aux | grep node | grep -v grep' 2>/dev/null; then
    echo "[info] Node process found"
  else
    echo "[warn] No node process detected"
  fi
  
  echo "[diag] Checking if port 8080 is listening..."
  if ssh -o StrictHostKeyChecking=no -o BatchMode=yes -i "$KEY" ec2-user@"$INSTANCE_IP" \
    'sudo ss -ltnp | grep 8080' 2>/dev/null; then
    echo "[info] Port 8080 is listening"
  else
    echo "[warn] Port 8080 not listening"
  fi
  
  echo "[diag] Checking app logs..."
  ssh -o StrictHostKeyChecking=no -o BatchMode=yes -i "$KEY" ec2-user@"$INSTANCE_IP" \
    'tail -n 50 /tmp/app.log 2>/dev/null || tail -n 50 /tmp/node-app.log 2>/dev/null || echo "No log found"' 2>/dev/null || true
fi

echo "[done] Finalization completed"
