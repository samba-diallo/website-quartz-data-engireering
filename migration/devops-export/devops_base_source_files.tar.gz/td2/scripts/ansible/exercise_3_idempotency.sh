#!/usr/bin/env bash
set -euo pipefail

# Script to demonstrate Exercise 3: Ansible Idempotency
# This script runs the configure playbook twice and compares the outputs.

ROOT_DIR=$(cd "$(dirname "$0")" && pwd)
cd "$ROOT_DIR"

PROFILE="${AWS_PROFILE:-labs-devops_diallo}"
REGION="us-east-2"

echo "=========================================="
echo "Exercise 3: Ansible Idempotency Test"
echo "=========================================="
echo ""
echo "This script runs configure_sample_app_playbook.yml TWICE"
echo "and shows how Ansible handles repeated execution (idempotency)."
echo ""

echo "[Step 1] First execution of the configure playbook"
echo "===================="
ANSIBLE_PYTHON_INTERPRETER="$(which python3)" \
AWS_PROFILE="$PROFILE" \
ansible-playbook -i inventory.aws_ec2.yml configure_sample_app_playbook.yml 2>&1 | tee /tmp/run1.log

echo ""
echo "[Step 2] Second execution of the same playbook (should be mostly 'ok')"
echo "===================="
ANSIBLE_PYTHON_INTERPRETER="$(which python3)" \
AWS_PROFILE="$PROFILE" \
ansible-playbook -i inventory.aws_ec2.yml configure_sample_app_playbook.yml 2>&1 | tee /tmp/run2.log

echo ""
echo "[Analysis]"
echo "=========="
echo ""
echo "Comparing the two PLAY RECAP outputs:"
echo ""
echo "First run:"
grep "PLAY RECAP" -A 2 /tmp/run1.log || echo "No PLAY RECAP found"
echo ""
echo "Second run:"
grep "PLAY RECAP" -A 2 /tmp/run2.log || echo "No PLAY RECAP found"
echo ""

echo "Key observations:"
echo "1. First run: Some tasks show 'changed' (Node install, app.js copy, app start)"
echo "2. Second run: Most tasks show 'ok' (no changes), except 'Start sample app' may show 'changed'"
echo ""
echo "Why is 'Start sample app' NOT idempotent?"
echo "  - It uses a bare 'shell' command without 'changed_when: false' or 'when:' condition"
echo "  - Each execution relaunches the app → new process spawned → task always reports 'changed'"
echo "  - PROBLEM: Multiple node processes accumulate (non-idempotent behavior)"
echo ""
echo "SOLUTION: Modify the task to:"
echo "  Option A: Add 'changed_when: false' to suppress change reporting"
echo "  Option B: Add 'when: app_running.rc != 0' to only start if not running"
echo "  Option C: Use a systemd service (best practice) for proper idempotency"
echo ""

