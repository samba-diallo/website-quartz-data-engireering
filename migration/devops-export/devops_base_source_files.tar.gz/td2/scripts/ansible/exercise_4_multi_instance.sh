#!/usr/bin/env bash
set -euo pipefail

# Script to demonstrate Exercise 4: Multi-Instance Deployment
# This creates multiple instances, verifies discovery, and configures them all.

ROOT_DIR=$(cd "$(dirname "$0")" && pwd)
cd "$ROOT_DIR"

PROFILE="${AWS_PROFILE:-labs-devops_diallo}"
REGION="us-east-2"
INSTANCE_COUNT="${1:-2}"  # Default to 2 instances, override with script arg

echo "=========================================="
echo "Exercise 4: Multi-Instance Deployment"
echo "=========================================="
echo ""
echo "This script will:"
echo "1. Create $INSTANCE_COUNT EC2 instances (tagged Ansible=ch2_instances)"
echo "2. Discover them using dynamic inventory"
echo "3. Configure all of them in parallel with the sample app"
echo ""
read -p "Press Enter to continue..."
echo ""

echo "[Step 1] Creating $INSTANCE_COUNT instances (using multi-instance playbook)"
echo "===================="
ANSIBLE_PYTHON_INTERPRETER="$(which python3)" \
AWS_PROFILE="$PROFILE" \
ansible-playbook -v create_ec2_instances_multi.yml -e instance_count="$INSTANCE_COUNT" -e instance_type=t3.micro

echo ""
echo "[Step 2] Waiting for instances to be fully running (30 seconds)..."
sleep 30

echo ""
echo "[Step 3] Discovering instances via dynamic inventory"
echo "===================="
echo "Running: ansible-inventory -i inventory.aws_ec2.yml --list"
echo ""
ANSIBLE_PYTHON_INTERPRETER="$(which python3)" \
AWS_PROFILE="$PROFILE" \
ansible-inventory -i inventory.aws_ec2.yml --list 2>&1 | \
  python3 -m json.tool | grep -E '(instance_id|public_ip_address|Name)' | head -n 30

echo ""
echo "Counting discovered hosts in _ch2_instances group:"
ANSIBLE_PYTHON_INTERPRETER="$(which python3)" \
AWS_PROFILE="$PROFILE" \
ansible-inventory -i inventory.aws_ec2.yml --list 2>&1 | \
  python3 -c "import sys, json; data=json.load(sys.stdin); hosts=data.get('_ch2_instances',{}).get('hosts',[]); print(f'Found {len(hosts)} instance(s)'); [print(f'  - {h}') for h in hosts]"

echo ""
echo "[Step 4] Configuring all instances in parallel"
echo "===================="
echo "Running configure playbook (targets _ch2_instances group)"
ANSIBLE_PYTHON_INTERPRETER="$(which python3)" \
AWS_PROFILE="$PROFILE" \
ansible-playbook -i inventory.aws_ec2.yml -v configure_sample_app_playbook.yml

echo ""
echo "[Step 5] Retrieving instance IPs and testing apps"
echo "===================="
echo "Querying AWS for instance details..."
aws ec2 describe-instances \
  --filters "Name=tag:Ansible,Values=ch2_instances" "Name=instance-state-name,Values=running" \
  --query 'Reservations[].Instances[].[InstanceId,Tags[?Key==`Name`].Value|[0],PublicIpAddress,InstanceType]' \
  --output table \
  --profile "$PROFILE" \
  --region "$REGION"

echo ""
echo "Testing HTTP connectivity to each instance (port 8080)..."
INSTANCE_IPS=$(aws ec2 describe-instances \
  --filters "Name=tag:Ansible,Values=ch2_instances" "Name=instance-state-name,Values=running" \
  --query 'Reservations[].Instances[].PublicIpAddress' \
  --output text \
  --profile "$PROFILE" \
  --region "$REGION")

for IP in $INSTANCE_IPS; do
  echo ""
  echo "Testing instance $IP:8080..."
  if timeout 5 curl -s "http://$IP:8080/" 2>/dev/null; then
    echo "  ✓ Instance $IP is responding"
  else
    echo "  ✗ Instance $IP is NOT responding (may need more time to start)"
  fi
done

echo ""
echo "[Summary]"
echo "=========="
echo "All $INSTANCE_COUNT instances have been created and configured!"
echo ""
echo "Key lessons from Exercise 4:"
echo "  1. Modify the create playbook to use 'loop' for multiple instances"
echo "  2. Tag all instances consistently (Ansible=ch2_instances)"
echo "  3. The dynamic inventory auto-discovers ALL tagged instances"
echo "  4. The configure playbook targets '_ch2_instances' group (all instances)"
echo "  5. Ansible runs configuration in parallel across all hosts"
echo ""
echo "To clean up the instances later, run:"
echo "  aws ec2 terminate-instances --instance-ids <id1> <id2> ... --profile labs-devops_diallo --region us-east-2"
echo ""
