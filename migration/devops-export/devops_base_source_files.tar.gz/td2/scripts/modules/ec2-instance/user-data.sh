#!/bin/bash
mkdir -p /home/ec2-user
cat > /home/ec2-user/app.js << 'NODEJS'
const http = require('http');
const os = require('os');
const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end(`Hello from ${os.hostname()}!\n`);
});
server.listen(8080, '0.0.0.0', () => {
  console.log('Server running');
});
NODEJS
cd /home/ec2-user && nohup /usr/local/bin/node app.js > app.log 2>&1 &
