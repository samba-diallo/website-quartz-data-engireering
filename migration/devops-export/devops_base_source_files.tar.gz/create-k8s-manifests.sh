# Copier tout le script ci-dessus ici

#!/bin/bash

# Script pour créer/mettre à jour les fichiers Kubernetes
# Crée automatiquement tous les manifests corrigés pour le déploiement EKS

set -e

# Définir le répertoire de base
K8S_DIR="projet-final-devops/ecodata-platform/k8s"

# Créer le répertoire s'il n'existe pas
mkdir -p "$K8S_DIR"

echo "Création des fichiers Kubernetes pour EcoData Platform..."

# Fichier 1: namespace.yaml
cat > "$K8S_DIR/namespace.yaml" << 'EOF'
# Namespace pour l'application EcoData Platform
apiVersion: v1
kind: Namespace
metadata:
  name: ecodata
  labels:
    name: ecodata
EOF
echo "Créé: namespace.yaml"

# Fichier 2: secrets-and-pvc.yaml
cat > "$K8S_DIR/secrets-and-pvc.yaml" << 'EOF'
# Secret contenant les informations sensibles de la base de données
apiVersion: v1
kind: Secret
metadata:
  name: ecodata-secrets
  namespace: ecodata
type: Opaque
stringData:
  db-username: ecodata_user
  db-password: ecodata_password
  database-url: postgresql://ecodata_user:ecodata_password@ecodata-postgres:5432/ecodata_db
---
# PersistentVolumeClaim pour stocker les fichiers uploadés
# Note: ReadWriteOnce car EBS n'supporte que ce mode d'accès
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: ecodata-uploads-pvc
  namespace: ecodata
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 10Gi
EOF
echo "Créé: secrets-and-pvc.yaml"

# Fichier 3: postgres-statefulset.yaml
cat > "$K8S_DIR/postgres-statefulset.yaml" << 'EOF'
# StatefulSet pour PostgreSQL avec persistance de données
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: ecodata-postgres
  namespace: ecodata
  labels:
    app: ecodata
    component: database
spec:
  serviceName: ecodata-postgres
  replicas: 1
  selector:
    matchLabels:
      app: ecodata
      component: database
  template:
    metadata:
      labels:
        app: ecodata
        component: database
    spec:
      containers:
      - name: postgres
        image: postgres:15
        ports:
        - containerPort: 5432
          name: postgres
        # Variables d'environnement pour initialiser PostgreSQL
        env:
        - name: POSTGRES_DB
          value: "ecodata_db"
        - name: POSTGRES_USER
          valueFrom:
            secretKeyRef:
              name: ecodata-secrets
              key: db-username
        - name: POSTGRES_PASSWORD
          valueFrom:
            secretKeyRef:
              name: ecodata-secrets
              key: db-password
        # Volume pour persister les données
        volumeMounts:
        - name: postgres-storage
          mountPath: /var/lib/postgresql/data
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
  # Template de volume pour le stockage persistant
  volumeClaimTemplates:
  - metadata:
      name: postgres-storage
    spec:
      accessModes: [ "ReadWriteOnce" ]
      resources:
        requests:
          storage: 5Gi
---
# Service ClusterIP pour accéder à PostgreSQL depuis le cluster
apiVersion: v1
kind: Service
metadata:
  name: ecodata-postgres
  namespace: ecodata
  labels:
    app: ecodata
    component: database
spec:
  type: ClusterIP
  ports:
  - port: 5432
    targetPort: 5432
    protocol: TCP
    name: postgres
  selector:
    app: ecodata
    component: database
EOF
echo "Créé: postgres-statefulset.yaml"

# Fichier 4: backend-deployment.yaml
cat > "$K8S_DIR/backend-deployment.yaml" << 'EOF'
# Déploiement du backend FastAPI
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ecodata-backend
  namespace: ecodata
  labels:
    app: ecodata
    component: backend
spec:
  replicas: 2
  selector:
    matchLabels:
      app: ecodata
      component: backend
  template:
    metadata:
      labels:
        app: ecodata
        component: backend
    spec:
      containers:
      # Note: L'image sera mise à jour par le pipeline GitHub Actions avec l'URI ECR
      - name: backend
        image: 511211062907.dkr.ecr.eu-north-1.amazonaws.com/ecodata-backend:latest
        imagePullPolicy: Always
        ports:
        - containerPort: 8000
        # Variables d'environnement pour le backend
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: ecodata-secrets
              key: database-url
        # Volume pour les fichiers uploadés
        volumeMounts:
        - name: uploads
          mountPath: /app/uploads
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
      # Volume déclaration
      volumes:
      - name: uploads
        persistentVolumeClaim:
          claimName: ecodata-uploads-pvc
---
# Service ClusterIP pour accéder au backend depuis le cluster
apiVersion: v1
kind: Service
metadata:
  name: ecodata-backend
  namespace: ecodata
  labels:
    app: ecodata
    component: backend
spec:
  type: ClusterIP
  ports:
  - port: 8000
    targetPort: 8000
    protocol: TCP
    name: http
  selector:
    app: ecodata
    component: backend
EOF
echo "Créé: backend-deployment.yaml"

# Fichier 5: frontend-deployment.yaml
cat > "$K8S_DIR/frontend-deployment.yaml" << 'EOF'
# Déploiement du frontend Streamlit
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ecodata-frontend
  namespace: ecodata
  labels:
    app: ecodata
    component: frontend
spec:
  replicas: 2
  selector:
    matchLabels:
      app: ecodata
      component: frontend
  template:
    metadata:
      labels:
        app: ecodata
        component: frontend
    spec:
      containers:
      # Note: L'image sera mise à jour par le pipeline GitHub Actions avec l'URI ECR
      - name: frontend
        image: 511211062907.dkr.ecr.eu-north-1.amazonaws.com/ecodata-frontend:latest
        imagePullPolicy: Always
        ports:
        - containerPort: 8501
        # Variables d'environnement pour se connecter au backend
        env:
        - name: API_URL
          value: "http://ecodata-backend:8000"
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
---
# Service LoadBalancer pour accéder au frontend depuis internet
apiVersion: v1
kind: Service
metadata:
  name: ecodata-frontend
  namespace: ecodata
  labels:
    app: ecodata
    component: frontend
spec:
  type: LoadBalancer
  ports:
  - port: 8501
    targetPort: 8501
    protocol: TCP
    name: http
  selector:
    app: ecodata
    component: frontend
EOF
echo "Créé: frontend-deployment.yaml"

echo ""
echo "Tous les fichiers Kubernetes ont été créés/mis à jour avec succès!"
echo "Fichiers créés dans: $K8S_DIR"
echo ""
echo "Prochaines étapes:"
echo "1. Vérifier les fichiers: ls -la $K8S_DIR"
echo "2. Valider les manifests: kubectl apply --dry-run=client -f $K8S_DIR/"
echo "3. Committer et pousser: git add $K8S_DIR && git commit -m 'Update Kubernetes manifests' && git push origin main"
