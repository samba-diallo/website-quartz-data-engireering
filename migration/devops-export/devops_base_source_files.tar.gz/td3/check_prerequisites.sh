#!/bin/bash
# Script de vérification pour TD3 Part 1

echo "========================================================"
echo "  TD3 - Vérification des prérequis Part 1 (Ansible)"
echo "========================================================"
echo ""

# Couleurs
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

check_command() {
    if command -v $1 &> /dev/null; then
        echo -e "${GREEN}[OK]${NC} $1 installé: $(command -v $1)"
        $1 --version 2>&1 | head -1
    else
        echo -e "${RED}[ERREUR]${NC} $1 n'est pas installé"
        return 1
    fi
    echo ""
}

echo "1. Vérification des outils"
echo "--------------------------------------------------------"
check_command ansible
check_command aws
check_command packer
check_command tofu
check_command docker
check_command kubectl

echo "2. Vérification AWS"
echo "--------------------------------------------------------"
export AWS_PROFILE=labs-devops_diallo
export AWS_DEFAULT_REGION=us-east-2

if aws sts get-caller-identity &> /dev/null; then
    echo -e "${GREEN}[OK]${NC} AWS credentials valides"
    aws sts get-caller-identity | grep -E "UserId|Account|Arn"
else
    echo -e "${RED}[ERREUR]${NC} AWS credentials invalides"
fi
echo ""

echo "3. Vérification collection Ansible"
echo "--------------------------------------------------------"
if ansible-galaxy collection list | grep -q "amazon.aws"; then
    echo -e "${GREEN}[OK]${NC} Collection amazon.aws installée"
else
    echo -e "${YELLOW}[ATTENTION]${NC} Collection amazon.aws manquante"
    echo "      Installer avec: ansible-galaxy collection install amazon.aws"
fi
echo ""

echo "4. Vérification des fichiers TD3"
echo "--------------------------------------------------------"
cd /home/sable/devops_base/td3/scripts/ansible 2>/dev/null

files=(
    "create_ec2_instances_playbook.yml"
    "sample-app-vars.yml"
    "configure_sample_app_playbook.yml"
    "inventory.aws_ec2.yml"
    "configure_nginx_playbook.yml"
    "nginx-vars.yml"
    "group_vars/sample_app_instances.yml"
    "group_vars/nginx_instances.yml"
    "roles/nodejs-app/tasks/main.yml"
    "roles/sample-app/tasks/main.yml"
    "roles/sample-app/files/app.js"
    "roles/nginx/tasks/main.yml"
)

for file in "${files[@]}"; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}[OK]${NC} $file"
    else
        echo -e "${RED}[MANQUANT]${NC} $file"
    fi
done
echo ""

echo "5. Vérification instances EC2 existantes"
echo "--------------------------------------------------------"
instance_count=$(aws ec2 describe-instances \
    --filters "Name=instance-state-name,Values=running" \
              "Name=tag:Ansible,Values=sample_app_instances" \
    --query "Reservations[*].Instances[*].InstanceId" \
    --output text 2>/dev/null | wc -w)

if [ "$instance_count" -gt 0 ]; then
    echo -e "${YELLOW}[ATTENTION]${NC} $instance_count instances sample_app_instances en cours"
    echo "      IPs publiques:"
    aws ec2 describe-instances \
        --filters "Name=instance-state-name,Values=running" \
                  "Name=tag:Ansible,Values=sample_app_instances" \
        --query "Reservations[*].Instances[*].PublicIpAddress" \
        --output text 2>/dev/null | tr '\t' '\n' | sed 's/^/        /'
else
    echo -e "${GREEN}[OK]${NC} Aucune instance sample_app_instances en cours"
fi
echo ""

nginx_count=$(aws ec2 describe-instances \
    --filters "Name=instance-state-name,Values=running" \
              "Name=tag:Ansible,Values=nginx_instances" \
    --query "Reservations[*].Instances[*].InstanceId" \
    --output text 2>/dev/null | wc -w)

if [ "$nginx_count" -gt 0 ]; then
    echo -e "${YELLOW}[ATTENTION]${NC} $nginx_count instance nginx_instances en cours"
    echo "      IP publique:"
    aws ec2 describe-instances \
        --filters "Name=instance-state-name,Values=running" \
                  "Name=tag:Ansible,Values=nginx_instances" \
        --query "Reservations[*].Instances[*].PublicIpAddress" \
        --output text 2>/dev/null | sed 's/^/        /'
else
    echo -e "${GREEN}[OK]${NC} Aucune instance nginx_instances en cours"
fi
echo ""

echo "========================================================"
echo "  Résumé"
echo "========================================================"
echo ""
echo "Pour commencer Part 1 (Ansible):"
echo "  cd /home/sable/devops_base/td3/scripts/ansible"
echo "  export AWS_PROFILE=labs-devops_diallo"
echo "  export AWS_DEFAULT_REGION=us-east-2"
echo ""
echo "Puis suivez: /home/sable/devops_base/td3/GUIDE_TD3.md"
echo ""
