provider "aws" {
  region = "us-east-2"
}

module "child_accounts" {
  source = "../../modules/aws-organizations"

  # Set to false if you already enabled AWS Organizations in your account
  create_organization = true

  dev_account_email   = "samba.diallo@edu.esiee.fr"
  stage_account_email = "mouhamed.diop@edu.esiee.fr"
  prod_account_email  = "production@esiee.fr"
}
